<?php
session_start();
if(!isset($_SESSION['usr']) || !isset($_SESSION['pswd'])){
	header("Location: index.php");
}
ini_set('display_errors', 1);
error_reporting(E_ALL);
//include 'logoff.html';
//<!– in this example my content only containing a html with logout link–>

if( isset( $_POST['edit'] ) ) {
	$filename = $_POST['title'];
	$blog = $_POST['newcontent'];

	
	file_put_contents($filname."txt", "");
	$fp = fopen($filename,"w");
	fwrite($fp,$blog);
	fclose($fp);
	
}


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Blog-Pruefung</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
</head>
<?php

?>
<body>

	
		<div class="navbar">
			<div class="navbar-inner">
			<ul class="nav">
				<li><a href="content.php">Home</a></li>
				<li><a href="create.php">Create</a></li>
				<li class="active"><a href="edit.php">Edit</a></li>
				<li><a href="delete.php">Delete</a></li>
			</ul>
		</div>

          <p><legend>Edit a Blog</legend>
		  
		  Alle Blogtitel:<br/>
		  
		  <?php
			foreach (glob("*.txt") as $filename) {
				$info = pathinfo($filename);
				$file_name =  basename($filename,'.'.$info['extension']);
				echo "Filename: ".$file_name."<br>";
			}
		   
		  ?>
		  <form class="form-horizontal" action="edit.php" method="post">
					<dl>
					<dt>Welcher Blog willst du editieren:</dt>
					<dd><input type="text" name="title" value="<?php echo @$_POST['title']; ?>" /></dd>
					<dt>New Blog content</dt>
					<dd><textarea name="content" rows="5" cols="100" >
					<?php echo @$_POST['newcontent'];?></textarea></dd>
					</dl>
					<p>
						<input type="hidden" name="edit" value="1" />
						<input type="submit" class="btn btn-large btn-primary" value="Edit" />
					</p>
        </form>
		  
	
				
		  </p>
        </div>
      </div>
    </div>
	<h3><a href="./logout.php">Logout</a></h3>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</body>
</html>