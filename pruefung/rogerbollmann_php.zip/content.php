<?php
session_start();
if(!isset($_SESSION['usr']) || !isset($_SESSION['pswd'])){
	header("Location: index.php");
}
ini_set('display_errors', 1);
error_reporting(E_ALL);
//include 'logoff.html';
//<!– in this example my content only containing a html with logout link–>
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Blog-Pruefung</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
</head>
<?php

?>
<body>

	
		<div class="navbar">
			<div class="navbar-inner">
			<ul class="nav">
				<li class="active"><a href="#">Home</a></li>
				<li><a href="create.php">Create</a></li>
				<li><a href="edit.php">Edit</a></li>
				<li><a href="delete.php">Delete</a></li>
			</ul>
		</div>

          <p><legend>All Blogs</legend>
	
			<?php
			
				foreach (glob("*.txt") as $filename) {
					$info = pathinfo($filename);
					$file_name =  basename($filename,'.'.$info['extension']);
					echo "Filename: ".$file_name."<br>";
					echo "$filename was last modified: " . date ("F d Y H:i:s.", filemtime($filename));
					echo "<br>Contenct:<br>";
					echo nl2br(file_get_contents($filename));
					echo "<br></br>";
				}
 
			?>
				
		  </p>
        </div>
      </div>
    </div>
	<h3><a href="./logout.php">Logout</a></h3>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</body>
</html>